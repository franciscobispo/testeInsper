﻿using Domain.Entities;
using Domain.Interfaces;
using Infra.Data.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Service.Services
{
    public class AulaService<T> : IAulaService<T> where T : Aula
    {
        private AulaRepository<T> aulaRepository = new AulaRepository<T>();

        public async Task<IList<Aula>> GetAllAsync()
        {
            //return await Task.Run(() => (List<Aula>)baseRepository.SelectAll());
            return await aulaRepository.GetAllAsync();

        }
        public async Task<IList<Aula>> SelectByQuantidadeAsync(int quantidadeListaAulas)
        {
            if (quantidadeListaAulas <= 0)
                throw new ArgumentException("Parâmetro 'quantidadeListaAulas' deve ser maior que zero.");

            return await aulaRepository.SelectByQuantidadeAsync(quantidadeListaAulas);

        }

        public async Task<Aula> GetByIdAsync(int idAula)
        {
            if (idAula <= 0)
                throw new ArgumentException("Parâmetro 'idAula' deve ser maior que zero.");

            return await aulaRepository.GetByIdAsync(idAula);

        }

        public async Task<int> PostAsync(Aula aula)
        {
            return await aulaRepository.PostAsync(aula);
        }
    }
}
