﻿using Domain.Entities;
using Domain.Interfaces;
using Infra.Data.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Service.Services
{
    public class UsuarioService<T> : IUsuarioService<T> where T : Usuario
    {
        private UsuarioRepository<T> usuarioRepository = new UsuarioRepository<T>();

        public async Task<Usuario> GetLoginAsync(string nome, string senha)
        {
            return await usuarioRepository.GetLoginAsync(nome, senha);
        }
    }
}
