﻿using Domain.Entities;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Service.Validators
{
    public class AulaValidator : AbstractValidator<Aula>
    {
        public AulaValidator()
        {
            RuleFor(c => c)
                    .NotNull()
                    .OnAnyFailure(x =>
                    {
                        throw new ArgumentNullException("Objeto não localizado.");
                    });

            RuleFor(c => c.Curso.Nome)
                .NotEmpty().WithMessage("É necessário informar o Nome do curso.")
                .NotNull().WithMessage("É necessário informar o Nome do curso.")
                .MinimumLength(3);

            RuleFor(c => c.Turma.Nome)
                .NotEmpty().WithMessage("É necessário informar o Nome da turma.")
                .NotNull().WithMessage("É necessário informar o Nome da turma.")
                .MinimumLength(3);
        }
    }
}
