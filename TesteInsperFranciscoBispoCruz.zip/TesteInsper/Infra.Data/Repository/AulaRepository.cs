﻿using Domain.Entities;
using Domain.Interfaces;
using Infra.Data.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.ChangeTracking.Internal;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infra.Data.Repository
{
	public class AulaRepository<T> : IAulaRepository<T> where T : Aula
	{
		private readonly DbContextOptions<SQLContext> _OptionsBuilder;
		private readonly BaseRepository<T> baseRepository;
		public AulaRepository()
		{
			_OptionsBuilder = new DbContextOptions<SQLContext>();
			baseRepository = new BaseRepository<T>();
		}

		public async Task<IList<Aula>> GetAllAsync()
		{
			using (var data = new SQLContext(_OptionsBuilder))
			{
				return await data.Set<Aula>()
											.Include(p => p.Curso)
											.Include(p => p.Turma)
											.Include(p => p.HorariosAula)
											.Include(p => p.HorariosAtendimento)
							.ToListAsync();
			}
		}

		public async Task<IList<Aula>> SelectByQuantidadeAsync(int quantidadeListaAulas)
		{
			using (var data = new SQLContext(_OptionsBuilder))
			{
				return await data.Set<Aula>()
											.Include(p => p.Curso)
											.Include(p => p.Turma)
											.Include(p => p.HorariosAula)
											.Include(p => p.HorariosAtendimento)
							.Take(quantidadeListaAulas).ToListAsync();
			}
		}

		public async Task<Aula> GetByIdAsync(int idAula)
		{
			using (var data = new SQLContext(_OptionsBuilder))
			{
				return await data.Set<Aula>()
											.Include(p => p.Curso)
											.Include(p => p.Turma)
											.Include(p => p.HorariosAula)
											.Include(p => p.HorariosAtendimento)
							.Where(a => a.Id.Equals(idAula)).FirstOrDefaultAsync();
			}
		}

		public async Task<int> PostAsync(Aula aula)
		{
			using (var data = new SQLContext(_OptionsBuilder))
			{
				var Curso = data.Curso.Find(aula.Curso.Id);
				var Turma = data.Turma.Find(aula.Turma.Id);
				aula.Curso = Curso;
				aula.Turma = Turma;
				var newAula = await data.Aula.AddAsync(aula);
				await data.SaveChangesAsync();
				return newAula.Entity.Id;
			}
		}
	}
}
