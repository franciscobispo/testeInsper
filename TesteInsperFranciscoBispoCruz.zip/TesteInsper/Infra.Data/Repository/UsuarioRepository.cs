﻿using Domain.Entities;
using Domain.Interfaces;
using Infra.Data.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.ChangeTracking.Internal;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infra.Data.Repository
{
	public class UsuarioRepository<T> : IUsuarioRepository<T> where T : Usuario
	{
		private readonly DbContextOptions<SQLContext> _OptionsBuilder;
		public UsuarioRepository()
		{
			_OptionsBuilder = new DbContextOptions<SQLContext>();
		}

		public async Task<Usuario> GetLoginAsync(string nome, string senha)
		{
			using (var data = new SQLContext(_OptionsBuilder))
			{
				return await data.Set<Usuario>()											
							.Where(a => a.Nome.ToLower().Equals(nome.ToLower()) && a.Senha.Equals(senha))
							.FirstOrDefaultAsync();
			}
		}
	}
}
