﻿using Domain.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Infra.Data.Context
{
    public class SQLContext : IdentityDbContext
    {
        public SQLContext(DbContextOptions<SQLContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

		public DbSet<Aula> Aula { get; set; }
        public DbSet<Curso> Curso { get; set; }
        public DbSet<Turma> Turma { get; set; }

        public DbSet<HorarioAula> HorarioAula { get; set; }
        public DbSet<HorarioAtendimento> HorarioAtendimento { get; set; }

        public DbSet<Usuario> Usuario { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
            if (!optionsBuilder.IsConfigured)
                optionsBuilder
                    .UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=TesteInsperFranciscoDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                    
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

            //Mock de dados
            modelBuilder.Entity<Usuario>().HasData(
                new Usuario { Id = 1, Nome = "Usuario Insper", Senha = "123456" }
            );

            modelBuilder.Entity<Curso>().HasData(
                new Curso { Id = 1, Nome = "Curso 1" }
            );

            modelBuilder.Entity<Turma>().HasData(
                new Curso { Id = 1, Nome = "Turma 1" }
            );

            //modelBuilder.Entity<HorarioAula>().HasData(
            //    new { Id = 1, DiaSemana = 2, Inicio = "08:00", Fim = "09:45", AulaId = 1 },
            //    new { Id = 2, DiaSemana = 3, Inicio = "11:00", Fim = "12:00", AulaId = 1 }
            //);

            //modelBuilder.Entity<HorarioAtendimento>().HasData(
            //    new { Id = 1, DiaSemana = 2, Inicio = "08:00", Fim = "12:00", AulaId = 1 },
            //    new { Id = 2, DiaSemana = 3, Inicio = "13:00", Fim = "18:00", AulaId = 1 }
            //);

            //modelBuilder.Entity<Aula>().HasData(
            //   new
            //   {
            //       Id = 1,
            //       CursoId = 1,
            //       TurmaId = 1,
            //       HorariosAulaId = 1,
            //       HorarioAtendimentoId = 1
            //   }

            //);
        }
	}
}
