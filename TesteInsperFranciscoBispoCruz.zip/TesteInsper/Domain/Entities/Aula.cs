﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities
{
    public class Aula : BaseEntity
    {
        public Curso Curso { get; set; }
        public Turma Turma { get; set; }
        public List<HorarioAula> HorariosAula { get; set; }
        public List<HorarioAtendimento> HorariosAtendimento { get; set; }
    }
}
