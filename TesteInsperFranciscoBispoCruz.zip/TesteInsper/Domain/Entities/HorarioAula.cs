﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities
{
    public class HorarioAula : BaseEntity
    {
        public string Inicio { get; set; }
        public string Fim { get; set; }
        public int DiaSemana { get; set; }
        public int AulaId { get; set; }
    }
}
