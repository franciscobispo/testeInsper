﻿namespace Domain.Entities
{
    public class Usuario : BaseEntity
    {
        public string Nome { get; set; }
        public string Senha { get; set; } //o ideal é ser criptografada (ex.: SHA256, RNG, ou outras libs de criptografia), mas para o teste vou implementá-la sem senha
        public string Token { get; set; }
    }
}
