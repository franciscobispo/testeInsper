﻿using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Interfaces
{
    public interface IUsuarioService<T> where T : Usuario
    {   
        Task<Usuario> GetLoginAsync(string nome, string senha);
    }
}
