﻿using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Interfaces
{
    public interface IAulaService<T> where T : Aula
    {
        Task<IList<Aula>> GetAllAsync();
        Task<IList<Aula>> SelectByQuantidadeAsync(int quantidadeListaAulas);
        Task<Aula> GetByIdAsync(int idAula);
        Task<int> PostAsync(Aula aula);
    }
}
