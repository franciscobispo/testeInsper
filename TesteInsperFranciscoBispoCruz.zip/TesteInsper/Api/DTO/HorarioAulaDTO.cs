﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities
{
    public class HorarioAulaDTO
    {
        public string Inicio { get; set; }
        public string Fim { get; set; }
        public int DiaSemana { get; set; }
    }
}
