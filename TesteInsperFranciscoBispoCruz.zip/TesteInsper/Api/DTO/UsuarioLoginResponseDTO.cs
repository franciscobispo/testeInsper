﻿namespace Api.DTO
{
    public class UsuarioLoginResponseDTO
    {
        public string Nome { get; set; }
        public string Token { get; set; }
    }
}
