﻿namespace Api.DTO
{
    public class UsuarioLoginDTO
    {
        public string Nome { get; set; }
        public string Senha { get; set; }
    }
}
