﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities
{
    public class AulaDTO : BaseEntity
    {
        public int CursoId { get; set; }
        public int TurmaId { get; set; }
        public List<HorarioAulaDTO> HorariosAula { get; set; }
        public List<HorarioAtendimentoDTO> HorariosAtendimento { get; set; }
    }
}
