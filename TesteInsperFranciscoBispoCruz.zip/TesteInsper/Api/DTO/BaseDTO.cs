﻿namespace Api.DTO
{
    public class BaseDTO
    {
    }
}
