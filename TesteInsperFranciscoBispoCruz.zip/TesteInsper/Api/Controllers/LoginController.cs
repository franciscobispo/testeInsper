﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Api.DTO;
using Domain.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Service.Services;

namespace Api.Controllers
{
    public class LoginController : Controller
    {
        private UsuarioService<Usuario> usuarioService = new UsuarioService<Usuario>();
        [HttpPost]
        [Route("login")]
        public async Task<ActionResult<UsuarioLoginResponseDTO>> Autenticar([FromBody] UsuarioLoginDTO usuarioLoginDTO)
        {
            try
            {
                if (usuarioLoginDTO == null)
                    return BadRequest(new { message = "Dados inválidos" });

                var usuario = await Task.Run(() => usuarioService.GetLoginAsync(usuarioLoginDTO.Nome, usuarioLoginDTO.Senha));
                if (usuario == null)
                    return NotFound(new { message = "Usuário não localizado" });

                UsuarioLoginResponseDTO usuarioDtoLogin = new UsuarioLoginResponseDTO
                {
                    Nome = usuario.Nome,
                    Token = GenerateToken(usuario)
                };

                return usuarioDtoLogin;
            }
            catch (Exception)
            {
                return Problem("Erro ao tentar efetuar login", null, 500, "Login error");
            }
        }

        private static string GenerateToken(Usuario usuario)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(Settings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, usuario.Nome.ToString()),
                    //new Claim(ClaimTypes.Role, usuario.Role.ToString())
                }),
                Expires = DateTime.UtcNow.AddHours(2),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
