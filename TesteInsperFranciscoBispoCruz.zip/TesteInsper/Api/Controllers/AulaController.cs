﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Service.Services;

namespace Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AulaController : ControllerBase
    {
        private AulaService<Aula> aulaService = new AulaService<Aula>();

        [HttpGet]
        [Route("ObterAulasAsync")]
        [Authorize]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                return new ObjectResult(await aulaService.GetAllAsync());
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("ObterAulasAsync/{quantidadeListaAulas}")]
        [Authorize]
        public async Task<IActionResult> ObterAulasAsync(int quantidadeListaAulas)
        {
            try
            {
                return new ObjectResult(await aulaService.SelectByQuantidadeAsync(quantidadeListaAulas));
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("ObterAulaEspecificaAsync/{idAula}")]
        [Authorize]
        public async Task<IActionResult> ObterAulaEspecificaAsync(int idAula)
        {
            try
            {
                return new ObjectResult(await aulaService.GetByIdAsync(idAula));
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Post(AulaDTO aulaDTO)
        {            
            try
            {
                List<HorarioAtendimento> horariosAtendimentoParsed = new List<HorarioAtendimento>();
                List<HorarioAula> horariosAulaParsed = new List<HorarioAula>();
                foreach (var itemHorariosAtendimento in aulaDTO.HorariosAtendimento)
                {
                    HorarioAtendimento newItemToAdd = new HorarioAtendimento()
                    {
                        AulaId = aulaDTO.Id,
                        DiaSemana = itemHorariosAtendimento.DiaSemana,
                        Inicio = itemHorariosAtendimento.Inicio,
                        Fim = itemHorariosAtendimento.Fim
                    };
                    horariosAtendimentoParsed.Add(newItemToAdd);
                }

                foreach (var itemHorariosAula in aulaDTO.HorariosAula)
                {
                    HorarioAula newItemToAdd = new HorarioAula()
                    {
                        AulaId = aulaDTO.Id,
                        DiaSemana = itemHorariosAula.DiaSemana,
                        Inicio = itemHorariosAula.Inicio,
                        Fim = itemHorariosAula.Fim
                    };
                    horariosAulaParsed.Add(newItemToAdd);
                }

                Aula aula = new Aula() { 
                    Id = aulaDTO.Id,
                    Curso = new Curso { Id = aulaDTO.CursoId },
                    Turma = new Turma { Id = aulaDTO.TurmaId },
                    HorariosAtendimento = horariosAtendimentoParsed,
                    HorariosAula = horariosAulaParsed
                };

                return new ObjectResult(await aulaService.PostAsync(aula));
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
    }
}
